# Sliceit

**End-to-end latency breakdown for any command.**  
Wrap any command and instantly see where time goes — compute, I/O, memory, or idle — in a rich terminal dashboard.

```
sliceit run -- python experiments/smoke_test.py
sliceit run -- pytest tests/
sliceit run -- npm test
sliceit run -- cargo build
```

---

## Requirements

- Python 3.9 or newer
- macOS, Linux, or Windows

---

## Installation

### From the wheel (fastest)

```bash
pip install sliceit-0.1.0-py3-none-any.whl
```

### From source

```bash
cd sliceit-src
pip install .
```

Both options automatically install the two dependencies: `rich` and `psutil`.

---

## Add to PATH (one-time setup)

After installing, you need the Python Scripts folder on your PATH so the `sliceit` command is found.

### Windows (PowerShell)

```powershell
$scripts = (python -c "import sysconfig; print(sysconfig.get_path('scripts'))")
[Environment]::SetEnvironmentVariable("PATH", $env:PATH + ";" + $scripts, "User")
```

Restart PowerShell after running this.

### macOS / Linux

```bash
export PATH="$HOME/.local/bin:$PATH"
```

Add that line to your `~/.bashrc` or `~/.zshrc` to make it permanent.

### Verify

```bash
sliceit --help
```

### Fallback (no PATH change needed)

If you'd rather not touch PATH, this always works:

```bash
# macOS / Linux
python -m sliceit run -- <command>

# Windows
python -c "from sliceit.cli import main; main()" run -- <command>
```

---

## Usage

```
sliceit run [options] -- <command>
```

### Options

| Flag | Description |
|------|-------------|
| `--repeat N` / `-n N` | Run N times and show a comparison table |
| `--quiet` / `-q` | One-line summary instead of full dashboard |
| `--no-capture` | Let the command's stdout/stderr print normally |

### Examples

```bash
# Profile a script
sliceit run -- python experiments/smoke_test.py
sliceit run -- python train.py
sliceit run -- node index.js

# Profile a test suite
sliceit run -- pytest tests/
sliceit run -- npm test
sliceit run -- cargo test

# Profile a build
sliceit run -- cargo build
sliceit run -- make build
sliceit run -- go build ./...

# Run 3 times and compare
sliceit run --repeat 3 -- pytest

# One-liner (good for CI logs)
sliceit run --quiet -- python script.py

# See your command's output AND the dashboard
sliceit run --no-capture -- cargo build
```

---

## What the dashboard shows

```
────────────────  Sliceit  python experiments/smoke_test.py  ──
  total  3.45s   samples  54   status  ✓ ok

╭─ timeline ──────────────────────────────────────────────────╮
│ ████████████████████████░░░░░░░░░░░░░░░░░░███████░░░░░░████ │
│   ▐ Compute  ▐ I/O  ▐ Memory  ▐ Idle                        │
╰─────────────────────────────────────────────────────────────╯

  Compute 7%    I/O 24%    Memory 4%    Idle 65%
  255ms         832ms      128ms        2.24s

╭─ phase breakdown ───────────────────────────────────────────╮
│  Waiting / blocked   Idle     1.44s  ████████████████████   │
│  Module load         I/O      440ms  ███████                │
│  Lock wait           Idle     435ms  ███████                │
│  Disk read           I/O      310ms  █████                  │
│  Parsing             Compute  123ms  ██                     │
╰─────────────────────────────────────────────────────────────╯

╭─ insight ───────────────────────────────────────────────────╮
│ 65% Idle — process mostly waiting on locks / child procs.   │
│ → Use async I/O, check if worker processes are stalling.    │
╰─────────────────────────────────────────────────────────────╯
```

### The four buckets

| Bucket | What it means |
|--------|---------------|
| **Compute** | CPU-bound work — inference, parsing, sorting, algorithms |
| **I/O** | Blocked on disk — model loading, dataset reads, file writes |
| **Memory** | GC pressure, heap allocation spikes |
| **Idle** | Waiting — arrival gaps, locks, child processes, network |

---

## How it works

Sliceit wraps your command in a subprocess and polls it (and all child processes) at 20Hz using `psutil`. Each sample is classified:

- **I/O** → bytes read/written per interval exceed threshold
- **Compute** → CPU% above 25%
- **Memory** → RSS growing faster than 512KB per sample
- **Idle** → everything else

Consecutive same-bucket samples are merged into named phases. Sampler overhead is under 1% CPU.

---

## Uninstall

```bash
pip uninstall sliceit
```

---

## License

MIT
